<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yi', 'jun', 'nong', 'chan', 'yi', 'dang', 'jing', 'xuan', 'kuai', 'jian', 'chu', 'dan', 'jiao', 'sha', 'zai', 'can',
  0x10 => 'bin', 'an', 'ru', 'tai', 'chou', 'chai', 'lan', 'ni', 'jin', 'qian', 'meng', 'wu', 'ning', 'qiong', 'ni', 'chang',
  0x20 => 'lie', 'lei', 'lu', 'kuang', 'bao', 'yu', 'biao', 'zan', 'zhi', 'si', 'you', 'hao', 'chen', 'chen', 'li', 'teng',
  0x30 => 'wei', 'long', 'chu', 'chan', 'rang', 'shu', 'hui', 'li', 'luo', 'zan', 'nuo', 'tang', 'yan', 'lei', 'nang', 'er',
  0x40 => 'wu', 'yun', 'zan', 'yuan', 'xiong', 'chong', 'zhao', 'xiong', 'xian', 'guang', 'dui', 'ke', 'dui', 'mian', 'tu', 'chang',
  0x50 => 'er', 'dui', 'er', 'jin', 'tu', 'si', 'yan', 'yan', 'shi', 'Shi ', 'dang', 'qian', 'dou', 'fen', 'mao', 'shen',
  0x60 => 'dou', 'Bai ', 'jing', 'li', 'huang', 'ru', 'wang', 'nei', 'quan', 'liang', 'yu', 'ba', 'gong', 'liu', 'xi', 'han',
  0x70 => 'lan', 'gong', 'tian', 'guan', 'xing', 'bing', 'qi', 'ju', 'dian', 'zi', 'fen', 'yang', 'jian', 'shou', 'ji', 'yi',
  0x80 => 'ji', 'chan', 'jiong', 'mao', 'ran', 'nei', 'yuan', 'mao', 'gang', 'ran', 'ce', 'jiong', 'ce', 'zai', 'gua', 'jiong',
  0x90 => 'mao', 'zhou', 'mao', 'gou', 'xu', 'mian', 'mi', 'rong', 'yin', 'xie', 'kan', 'jun', 'nong', 'yi', 'mi', 'shi',
  0xA0 => 'guan', 'meng', 'zhong', 'ju', 'yuan', 'ming', 'kou', 'lin', 'fu', 'xie', 'mi', 'bing', 'dong', 'tai', 'gang', 'feng',
  0xB0 => 'bing', 'hu', 'chong', 'jue', 'hu', 'kuang', 'ye', 'leng', 'pan', 'fu', 'min', 'dong', 'xian', 'lie', 'qia', 'jian',
  0xC0 => 'jing', 'shu', 'mei', 'tu', 'qi', 'gu', 'zhun', 'song', 'jing', 'liang', 'qing', 'diao', 'ling', 'dong', 'gan', 'jian',
  0xD0 => 'yin', 'cou', 'yi', 'li', 'chuang', 'ming', 'zhun', 'cui', 'si', 'duo', 'jin', 'lin', 'lin', 'ning', 'xi', 'du',
  0xE0 => 'ji', 'fan', 'fan', 'fan', 'feng', 'ju', 'chu', 'zheng', 'feng', 'mu', 'zhi', 'fu', 'feng', 'ping', 'feng', 'kai',
  0xF0 => 'huang', 'kai', 'gan', 'deng', 'ping', 'qian', 'xiong', 'kuai', 'tu', 'ao', 'chu', 'ji', 'dang', 'han', 'han', 'zao',
];
