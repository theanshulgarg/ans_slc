<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'sha', 'li', 'han', 'xian', 'jing', 'pai', 'fei', 'xiao', 'bai', 'qi', 'ni', 'biao', 'yin', 'lai', 'lie', 'jian',
  0x10 => 'qiang', 'kun', 'yan', 'guo', 'zong', 'mi', 'chang', 'yi', 'zhi', 'zheng', 'ya', 'meng', 'cai', 'cu', 'she', 'lie',
  0x20 => 'dian', 'luo', 'hu', 'zong', 'gui', 'wei', 'feng', 'wo', 'yuan', 'xing', 'zhu', 'mao', 'wei', 'chuan', 'xian', 'tuan',
  0x30 => 'ya', 'nao', 'xie', 'jia', 'hou', 'bian', 'you', 'you', 'mei', 'cha', 'yao', 'sun', 'bo', 'ming', 'hua', 'yuan',
  0x40 => 'sou', 'ma', 'yuan', 'dai', 'yu', 'shi', 'hao', 'qiang', 'yi', 'zhen', 'cang', 'hao', 'man', 'jing', 'jiang', 'mo',
  0x50 => 'zhang', 'chan', 'ao', 'ao', 'hao', 'cui', 'ben', 'jue', 'bi', 'bi', 'huang', 'pu', 'lin', 'xu', 'tong', 'yao',
  0x60 => 'liao', 'shuo', 'xiao', 'shou', 'dun', 'jiao', 'ge', 'juan', 'du', 'hui', 'kuai', 'xian', 'xie', 'ta', 'xian', 'xun',
  0x70 => 'ning', 'pin', 'huo', 'nou', 'meng', 'lie', 'nao', 'guang', 'shou', 'lu', 'ta', 'xian', 'mi', 'rang', 'huan', 'nao',
  0x80 => 'luo', 'xian', 'qi', 'jue', 'xuan', 'miao', 'zi', 'lu', 'lu', 'yu', 'su', 'wang', 'qiu', 'ga', 'ding', 'le',
  0x90 => 'ba', 'ji', 'hong', 'di', 'chuan', 'gan', 'jiu', 'yu', 'qi', 'yu', 'chang', 'ma', 'gong', 'wu', 'fu', 'wen',
  0xA0 => 'jie', 'ya', 'bin', 'bian', 'bang', 'yue', 'jue', 'men', 'jue', 'wan', 'jian', 'mei', 'dan', 'pin', 'wei', 'huan',
  0xB0 => 'xian', 'qiang', 'ling', 'dai', 'yi', 'an', 'ping', 'dian', 'fu', 'xuan', 'xi', 'bo', 'ci', 'gou', 'jia', 'shao',
  0xC0 => 'po', 'ci', 'ke', 'ran', 'sheng', 'shen', 'yi', 'zu', 'jia', 'min', 'shan', 'liu', 'bi', 'zhen', 'zhen', 'jue',
  0xD0 => 'fa', 'long', 'jin', 'jiao', 'jian', 'li', 'guang', 'xian', 'zhou', 'gong', 'yan', 'xiu', 'yang', 'xu', 'luo', 'su',
  0xE0 => 'zhu', 'qin', 'yin', 'xun', 'bao', 'er', 'xiang', 'yao', 'xia', 'hang', 'gui', 'chong', 'xu', 'ban', 'pei', 'lao',
  0xF0 => 'dang', 'ying', 'hui', 'wen', 'e', 'cheng', 'di', 'wu', 'wu', 'cheng', 'jun', 'mei', 'bei', 'ting', 'xian', 'chu',
];
